% dPki/dVk

i   k        i,k          i,1           k,1     i,k             i,2         k,2     i,k             i,2          k,2
2	1 =-2* G(2,1)* tabela(2,1)+ tabela(1,1)*( G(2,1)*cos(tabela(2,2)-tabela(1,2))+B(2,1)*sin(tabela(2,2)-tabela(1,2)))
5	1 =-2* G(5,1)* tabela(5,1)+ tabela(1,1)*( G(5,1)*cos(tabela(5,2)-tabela(1,2))+B(5,1)*sin(tabela(5,2)-tabela(1,2)))
3	2 =-2* G(3,2)* tabela(3,1)+ tabela(2,1)*( G(3,2)*cos(tabela(3,2)-tabela(2,2))+B(3,1)*sin(tabela(3,2)-tabela(2,2)))
4	3 =-2* G(4,3)* tabela(4,1)+ tabela(3,1)*( G(4,3)*cos(tabela(4,2)-tabela(3,2))+B(4,3)*sin(tabela(4,2)-tabela(3,2)))
5	4 =-2* G(5,4)* tabela(5,1)+ tabela(4,1)*( G(5,4)*cos(tabela(5,2)-tabela(4,2))+B(5,4)*sin(tabela(5,2)-tabela(4,2)))
2	5 =-2* G(2,1)* tabela(2,1)+ tabela(5,1)*( G(2,5)*cos(tabela(2,2)-tabela(1,2))+B(5,2)*sin(tabela(5,2)-tabela(2,2)))


%dPki/dVi
i   k          i,1     i,k             i,2         k,2     i,k              i,2        k,2
2	1 =tabela(2,1)*( G(2,1)*cos(tabela(2,2)-tabela(1,2))+B(2,1)*sin(tabela(2,2)-tabela(1,2)))
5	1 =tabela(5,1)*( G(5,1)*cos(tabela(5,2)-tabela(1,2))+B(5,1)*sin(tabela(5,2)-tabela(1,2)))
3	2 =tabela(3,1)*( G(3,2)*cos(tabela(3,2)-tabela(2,2))+B(3,2)*sin(tabela(3,2)-tabela(2,2)))
4	3 =tabela(4,1)*( G(4,3)*cos(tabela(4,2)-tabela(3,2))+B(4,3)*sin(tabela(4,2)-tabela(5,2)))
5	4 =tabela(5,1)*( G(5,4)*cos(tabela(5,2)-tabela(4,2))+B(5,4)*sin(tabela(5,2)-tabela(4,2)))
2	5 =tabela(2,1)*( G(2,5)*cos(tabela(2,2)-tabela(5,2))+B(2,5)*sin(tabela(2,2)-tabela(5,2)))

%dPki/D?k
i   k         i,1         k,1       i,k             i,2         k,2     i,k             i ,2       k,2
2	1 =tabela(2,1)*tabela(1,1)*( -G(2,1)*sin(tabela(2,2)-tabela(1,2))+B(2,1)*cos(tabela(2,2)-tabela(1,2)))
5	1 =tabela(5,1)*tabela(1,1)*( -G(5,1)*sin(tabela(5,2)-tabela(1,2))+B(5,1)*cos(tabela(5,2)-tabela(1,2)))
3	2 =tabela(3,1)*tabela(2,1)*( -G(3,2)*sin(tabela(3,2)-tabela(2,2))+B(3,2)*cos(tabela(2,2)-tabela(2,2)))
4	3 =tabela(4,1)*tabela(3,1)*( -G(4,3)*sin(tabela(4,2)-tabela(3,2))+B(4,3)*cos(tabela(4,2)-tabela(2,2)))
5	4 =tabela(5,1)*tabela(4,1)*( -G(5,4)*sin(tabela(5,2)-tabela(4,2))+B(5,4)*cos(tabela(5,2)-tabela(4,2)))
2	5 =tabela(2,1)*tabela(5,1)*( -G(2,5)*sin(tabela(2,2)-tabela(5,2))+B(2,5)*cos(tabela(2,2)-tabela(1,2)))

%dPki/D?i
ou - dPki/D?k
% 2	1 =tabela(2,1)*tabela(1,1)*(-G(2,1)*sin(tabela(2,2)-tabela(1,2))+B(2,1)*cos(tabela(2,2)-tabela(1,2)))
% 2	5 =tabela(3,1)*tabela(1,1)*(-G(3,1)*sin(tabela(2,2)-tabela(1,2))+B(3,1)*cos(tabela(2,2)-tabela(1,2)))
% 5	1 =tabela(5,1)*tabela(1,1)*(-G(5,1)*sin(tabela(5,2)-tabela(1,2))+B(5,1)*cos(tabela(5,2)-tabela(1,2)))
% 3	2 =tabela(3,1)*tabela(2,1)*(-G(3,2)*sin(tabela(2,2)-tabela(2,2))+B(3,1)*cos(tabela(2,2)-tabela(2,2)))
% 4	3 =tabela(4,1)*tabela(3,1)*(-G(4,3)*sin(tabela(4,2)-tabela(2,2))+B(4,3)*cos(tabela(4,2)-tabela(2,2)))
% 5	4 =tabela(5,1)*tabela(4,1)*(-G(5,4)*sin(tabela(5,2)-tabela(4,2))+B(5,4)*cos(tabela(5,2)-tabela(4,2)))
